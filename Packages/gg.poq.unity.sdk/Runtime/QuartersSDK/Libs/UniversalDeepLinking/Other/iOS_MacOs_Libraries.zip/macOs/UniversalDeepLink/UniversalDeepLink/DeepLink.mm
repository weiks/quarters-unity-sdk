//
//  DeepLink.m
//  UniversalDeepLink
//
//  Created by Ana Correia on 28/04/2018.
//  Copyright © 2018 ImaginationOverflow. All rights reserved.
//

#import "LinkerManager.h"

extern "C"
{
    
    void DeepLink_RegisterCallback(EventCallback callback)
    {
        [[LinkerManager instance] registerCallback:callback];
    }
    
}
