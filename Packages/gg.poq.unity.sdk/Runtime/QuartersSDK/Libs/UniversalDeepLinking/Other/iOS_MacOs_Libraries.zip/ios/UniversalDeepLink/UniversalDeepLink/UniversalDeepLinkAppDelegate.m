//
//  UniversalDeepLinkDelegate.m
//  UniversalDeepLink
//
//  Created by Ana Correia on 06/04/2018.
//  Copyright © 2018 ImaginationOverflow. All rights reserved.
//

#import "UniversalDeepLinkAppDelegate.h"

@implementation UniversalDeepLinkAppDelegate


#pragma mark Override implementations

-(BOOL)application:(UIApplication*) application didFinishLaunchingWithOptions:(NSDictionary*) launchOptions
{
    NSLog(@"[UniversalDeepLinkDelegate v1111]");
    NSLog(@"[UniversalDeepLinkDelegate application:%@ didFinishLaunchingWithOptions:%@]", application, launchOptions);
    return [self _Universal_Deep_Link_Plugin_Application:application
                           didFinishLaunchingWithOptions:launchOptions];
}

-(BOOL)application:(UIApplication*) application
           openURL:(NSURL*) url
           options:(NSDictionary<NSString*, id>*) options
{
    NSLog(@"[UniversalDeepLinkDelegate application:%@ openURL:%@ options:%@]", application, url, options);
    [[LinkerManager instance] receiveLink:url.absoluteString];
    
    return [self _Universal_Deep_Link_Plugin_Application:application
                                                 openURL:url
                                                 options:options];
}

-(BOOL)application:(UIApplication*) application
           openURL:(NSURL*) url
 sourceApplication:(NSString*) sourceApplication
        annotation:(id) annotation
{
    NSLog(@"[UniversalDeepLinkDelegate application:%@ openURL:%@ sourceApplication:%@ annotation:%@]", application, url, sourceApplication, annotation);
    [[LinkerManager instance] receiveLink:url.absoluteString];

    return [self _Universal_Deep_Link_Plugin_Application:application
                                                 openURL:url
                                       sourceApplication:sourceApplication
                                              annotation:(annotation) ? annotation : [NSDictionary new]];
}


-(BOOL)application:(UIApplication *)application continueUserActivity:(NSUserActivity *)userActivity restorationHandler:(void(^)(NSArray * __nullable restorableObjects))restorationHandler
{
     NSLog(@"[UniversalDeepLinkDelegate application:%@ continueUserActivity ]",application);
    if ([userActivity.activityType isEqualToString:NSUserActivityTypeBrowsingWeb])
    {
        NSLog(@"[UniversalDeepLinkDelegate application:%@ continueUserActivity url:%@ ]", application, userActivity.webpageURL);
        /*[self application:application openURL:userActivity.webpageURL sourceApplication:nil annotation:[NSDictionary dictionary]];*/
         
         [[LinkerManager instance] receiveLink: userActivity.webpageURL.absoluteString];
    
    }
   /* else if ([userActivity.activityType isEqualToString:CSSearchableItemActionType])
    {
        NSString *uniqueIdentifier = [userActivity.userInfo objectForKey:CSSearchableItemActivityIdentifier];
        NSLog(@"%@",uniqueIdentifier);
        [[LinkerManager instance] receiveLink: uniqueIdentifier];
    }*/
    
    return YES;
}

#pragma mark Original implementation placeholders

-(BOOL)_Universal_Deep_Link_Plugin_Application:(UIApplication*) application
                 didFinishLaunchingWithOptions:(NSDictionary*) launchOptions
{ return YES; }


-(BOOL)_Universal_Deep_Link_Plugin_Application:(UIApplication*) application
                                       openURL:(NSURL*) url
                                       options:(NSDictionary<NSString*, id>*) options
{ return YES; }


-(BOOL)_Universal_Deep_Link_Plugin_Application:(UIApplication*) application
                                       openURL:(NSURL*) url
                             sourceApplication:(NSString*) sourceApplication
                                    annotation:(id) annotation
{ return YES; }


-(BOOL)_Universal_Deep_Link_Plugin_Application:(UIApplication *)application
                          continueUserActivity:(NSUserActivity *)userActivity

                            restorationHandler:(void(^)(NSArray * restorableObjects))restorationHandler
{
    return YES;
}



@end

