//
//  LinkerManager.h
//  UniversalDeepLink
//
//  Created by Ana Correia on 27/04/2018.
//  Copyright © 2018 ImaginationOverflow. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef void (*EventCallback)(const char * link);

@interface LinkerManager : NSObject

@property (nonatomic, assign) EventCallback callback;
@property (nonatomic, assign) BOOL openByNotification;
@property (nonatomic, assign) BOOL newDeepLink;
@property (nonatomic, strong) NSString * saveLink;
@property (nonatomic, strong) NSString * sourceApplication;
@property (nonatomic, strong) id annotation;

+(LinkerManager*)instance;

-(void)reset;

-(void) registerCallback:(EventCallback) callback;

-(void) receiveLink:(NSString *) link;


@end
