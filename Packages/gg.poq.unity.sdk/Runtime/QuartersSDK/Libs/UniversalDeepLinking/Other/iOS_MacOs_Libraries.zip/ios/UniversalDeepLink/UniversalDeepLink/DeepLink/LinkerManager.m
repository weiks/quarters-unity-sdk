//
//  LinkerManager.m
//  UniversalDeepLink
//
//  Created by Ana Correia on 06/04/2018.
//  Copyright © 2018 ImaginationOverflow. All rights reserved.
//

#import "LinkerManager.h"
#import "StringUtils.h"

__strong LinkerManager *_instance;

@implementation LinkerManager

+(void)load
{
    NSLog(@"[LinkerManager load]");
    _instance = [LinkerManager new];
}

+(LinkerManager*)instance
{ return _instance; }

-(instancetype)init
{
    self = [super init];
    if (self)
    {
        [self reset];
        self.callback = NULL;
    }
    return self;
}

-(void)reset
{
    self.saveLink = NULL;
    self.openByNotification = FALSE;
    self.newDeepLink = FALSE;
}

-(void) registerCallback:(EventCallback) callback
{
    NSLog(@"[[LinkerManager registerCallback]]");
    
    self.callback = callback;
    [self sendSaveLink];
}

-(void) sendOrSaveLink:(NSString *) link;
{
    NSLog(@"[[LinkerManager sendOrSaveLink]]");
    
    self.saveLink = link;
    
    if(self.callback != NULL)
    {
        [self sendSaveLink];
    }else
    {
        NSLog(@"[[LinkerManager sendSaveLink] Save Link = %@]", link);
        self.saveLink = link;
    }
}

-(void)sendSaveLink
{
    NSLog(@"[[LinkerManager sendSaveLink]]");
    
    if(self.callback != NULL && self.newDeepLink)
    {
        NSLog(@"[[LinkerManager sendSaveLink] Send Save Link = %@]", self.saveLink);
        
        const char * url = [StringUtils UnityStringFromNSString:self.saveLink];
        
        self.callback(url);
        [self reset];
    }
}

-(void) receiveLink:(NSString *) link
{
    NSLog(@"[[LinkerManager receiveLink] Receive Link = %@]", link);
    
    self.newDeepLink = TRUE;
    
    [self sendOrSaveLink: link];
}

@end

