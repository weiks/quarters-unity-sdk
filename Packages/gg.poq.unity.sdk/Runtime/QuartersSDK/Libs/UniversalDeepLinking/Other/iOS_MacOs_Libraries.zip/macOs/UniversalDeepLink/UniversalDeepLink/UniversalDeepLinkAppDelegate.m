//
//  UniversalDeepLinkAppDelegate.m
//  UniversalDeepLink
//
//  Created by Ana Correia on 27/04/2018.
//  Copyright © 2018 ImaginationOverflow. All rights reserved.
//

#import "UniversalDeepLinkAppDelegate.h"

@implementation UniversalDeepLinkAppDelegate

#pragma mark UniversalDeepLink implementations

-(void)applicationDidFinishLaunching:(NSNotification*) notification
{
    NSLog(@"[UniversalDeepLinkAppDelegate applicationDidFinishLaunching:%@]", notification);
    return [self _Universal_Deep_Link_Plugin_Application_applicationDidFinishLaunching:notification];
}


#pragma mark Original implementation placeholders

-(void)_Universal_Deep_Link_Plugin_Application_applicationDidFinishLaunching:(NSNotification*) notification
{ return; }


@end
