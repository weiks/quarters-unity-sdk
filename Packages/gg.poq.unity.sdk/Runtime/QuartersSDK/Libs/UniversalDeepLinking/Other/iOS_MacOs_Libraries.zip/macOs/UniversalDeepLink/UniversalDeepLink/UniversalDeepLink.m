//
//  UniversalDeepLink.m
//  UniversalDeepLink
//
//  Created by Ana Correia on 27/04/2018.
//  Copyright © 2018 ImaginationOverflow. All rights reserved.
//

#import "UniversalDeepLink.h"

@implementation UniversalDeepLink


+(void)load
{
    NSLog(@"[UniversalDeepLink load]");
    [self swizzle];
}

+(void)swizzle
{
    NSLog(@"[UniversalDeepLink swizzle]");
    [self replaceAppDelegateMethod:@selector(applicationDidFinishLaunching:)
                         fromClass:UniversalDeepLinkAppDelegate.class savingOriginalTo:@selector(_Universal_Deep_Link_Plugin_Application_applicationDidFinishLaunching:)];
    
}

+(void)replaceAppDelegateMethod:(SEL) unitySelector
                      fromClass:(Class) overrideAppDelegate
               savingOriginalTo:(SEL) savingOriginalSelector
{
    // The Unity base app controller class (the class name stored in `AppControllerClassName`).
    Class unityAppDelegate = NSClassFromString(@"PlayerAppDelegate");
    
    // See log messages for the sake of this tutorial.
    [Swizzler setLogging:YES];
    
    // Add empty placholder to Unity app delegate.
    [Swizzler addInstanceMethod:savingOriginalSelector
                            toClass:unityAppDelegate
                          fromClass:overrideAppDelegate];
    
    // Save the original Unity app delegate implementation into.
    [Swizzler swapInstanceMethod:savingOriginalSelector
                  withInstanceMethod:unitySelector
                             ofClass:unityAppDelegate];
    
    // Replace Unity app delegate with ours.
    [Swizzler replaceInstanceMethod:unitySelector
                                ofClass:unityAppDelegate
                              fromClass:overrideAppDelegate];
}


@end
