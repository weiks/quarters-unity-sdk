//
//  StringUtilis.m
//  UniversalDeepLink
//
//  Created by Ana Correia on 13/04/2018.
//  Copyright © 2018 ImaginationOverflow. All rights reserved.
//

#import "StringUtils.h"

@implementation StringUtils

+(const char*) UnityStringFromNSString:(NSString*) string;
{
    if([StringUtils NSStringIsNilOrEmpty: string] == TRUE)
         return NULL;
    
    if (string == nil)
        return NULL;
    
    const char* cString = string.UTF8String;
    char* _unityString = (char*)malloc(strlen(cString) + 1);
    strcpy(_unityString, cString);
    return _unityString;
}

+(NSString*) NSStringFromUnityString:(const char*) unityString
{
    if (unityString == nil)
        return [NSString new];
    
    return [NSString stringWithUTF8String:unityString];
}

+(BOOL)NSStringIsNilOrEmpty:(NSString*)string; {
    return !(string && string.length);
}

@end
