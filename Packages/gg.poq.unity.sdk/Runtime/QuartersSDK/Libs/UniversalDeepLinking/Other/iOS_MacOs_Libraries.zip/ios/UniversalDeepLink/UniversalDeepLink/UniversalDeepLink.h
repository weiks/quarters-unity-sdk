//
//  UniversalDeepLink.h
//  UniversalDeepLink
//
//  Created by Ana Correia on 06/04/2018.
//  Copyright © 2018 ImaginationOverflow. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "Swizzler.h"
#import "UniversalDeepLinkAppDelegate.h"

@interface UniversalDeepLink : NSObject

@end
