//
//  UniversalDeepLink.m
//  UniversalDeepLink
//
//  Created by Ana Correia on 06/04/2018.
//  Copyright © 2018 ImaginationOverflow. All rights reserved.
//

#import "UniversalDeepLink.h"
#import <objc/runtime.h>


@implementation UniversalDeepLink



+(void)load
{
    NSLog(@"[UniversalDeepLink load]");
    [self swizzle];
}

+(void)swizzle
{
    NSLog(@"[UniversalDeepLink swizzle]");
    [self replaceAppDelegateMethod:@selector(application:didFinishLaunchingWithOptions:)
                         fromClass:UniversalDeepLinkAppDelegate.class
                  savingOriginalTo:@selector(_Universal_Deep_Link_Plugin_Application:didFinishLaunchingWithOptions:)];
    
    [self replaceAppDelegateMethod:@selector(application:openURL:options:)
                         fromClass:UniversalDeepLinkAppDelegate.class
                  savingOriginalTo:@selector(_Universal_Deep_Link_Plugin_Application:openURL:options:)];
    
    [self replaceAppDelegateMethod:@selector(application:openURL:sourceApplication:annotation:)
                         fromClass:UniversalDeepLinkAppDelegate.class
                  savingOriginalTo:@selector(_Universal_Deep_Link_Plugin_Application:openURL:sourceApplication:annotation:)];
    
    
    //Class unityAppDelegate = NSClassFromString(@"UnityAppController");
    
    Class unityAppDelegate = NSClassFromString(@"UnityAppController");
    
    NSArray * subClasses = [self classGetSubclasses:unityAppDelegate];
    
     NSLog(@"[UniversalDeepLink swizzle - SubClasses] %lu",[subClasses count]);
    
    if([subClasses count] > 0)
    {
        unityAppDelegate = [subClasses lastObject];
        
         NSLog(@"[UniversalDeepLink swizzle - SubClasses] - Name %@",NSStringFromClass(unityAppDelegate));
    }
    
    // See log messages for the sake of this tutorial.
    [EPPZSwizzler setLogging:YES];
    
    // Add empty placholder to Unity app delegate.
    [EPPZSwizzler addInstanceMethod:@selector(application:continueUserActivity:restorationHandler:)
                            toClass:unityAppDelegate
                          fromClass:UniversalDeepLinkAppDelegate.class];

    [self replaceAppDelegateMethod:@selector(application:continueUserActivity:restorationHandler:)
                         fromClass:UniversalDeepLinkAppDelegate.class savingOriginalTo:@selector(_Universal_Deep_Link_Plugin_Application:continueUserActivity:restorationHandler:)];
    
    
}

+(void)replaceAppDelegateMethod:(SEL) unitySelector
                      fromClass:(Class) overrideAppDelegate
               savingOriginalTo:(SEL) savingOriginalSelector
{
    // The Unity base app controller class (the class name stored in `AppControllerClassName`).
   // Class unityAppDelegate = NSClassFromString(@"UnityAppController");
    
    Class unityAppDelegate = NSClassFromString(@"UnityAppController");
    
    NSArray * subClasses = [self classGetSubclasses:unityAppDelegate];
    
     NSLog(@"[UniversalDeepLink swizzle - SubClasses] %lu",[subClasses count]);
    
    if([subClasses count] > 0)
    {
        unityAppDelegate = [subClasses lastObject];
        
         NSLog(@"[UniversalDeepLink swizzle - SubClasses] - Name %@",NSStringFromClass(unityAppDelegate));
    }
    
    
    // See log messages for the sake of this tutorial.
    [EPPZSwizzler setLogging:YES];
    
    // Add empty placholder to Unity app delegate.
    [EPPZSwizzler addInstanceMethod:savingOriginalSelector
                            toClass:unityAppDelegate
                          fromClass:overrideAppDelegate];
    
    // Save the original Unity app delegate implementation into.
    [EPPZSwizzler swapInstanceMethod:savingOriginalSelector
                  withInstanceMethod:unitySelector
                             ofClass:unityAppDelegate];
    
    // Replace Unity app delegate with ours.
    [EPPZSwizzler replaceInstanceMethod:unitySelector
                                ofClass:unityAppDelegate
                              fromClass:overrideAppDelegate];
}



+(NSArray *) classGetSubclasses:(Class) parentClass
{
  int numClasses = objc_getClassList(NULL, 0);
  Class *classes = NULL;

  classes = (__unsafe_unretained Class *)malloc(sizeof(Class) * numClasses);
  numClasses = objc_getClassList(classes, numClasses);

  NSMutableArray * result = [NSMutableArray array];
  for (NSInteger i = 0; i < numClasses; i++)
  {
    Class superClass = classes[i];
    do
    {
      superClass = class_getSuperclass(superClass);
    } while(superClass && superClass != parentClass);

    if (superClass == nil)
    {
      continue;
    }

    [result addObject:classes[i]];
  }

  free(classes);

  return result;
}


@end
