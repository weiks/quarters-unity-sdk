//
//  StringUtilis.h
//  UniversalDeepLink
//
//  Created by Ana Correia on 13/04/2018.
//  Copyright © 2018 ImaginationOverflow. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface StringUtils : NSObject

+(const char*) UnityStringFromNSString:(NSString*) string;

+(NSString*) NSStringFromUnityString:(const char*) unityString;

+(BOOL)NSStringIsNilOrEmpty:(NSString*)string;

@end
