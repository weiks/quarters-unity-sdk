//
//  UniversalDeepLinkAppDelegate.h
//  UniversalDeepLink
//
//  Created by Ana Correia on 27/04/2018.
//  Copyright © 2018 ImaginationOverflow. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AppKit/AppKit.h>
#import "UniversalDeepLink.h"
#import "LinkerManager.h"


@interface UniversalDeepLinkAppDelegate : NSObject


-(void)applicationDidFinishLaunching:(NSNotification*) notification;
-(void)_Universal_Deep_Link_Plugin_Application_applicationDidFinishLaunching:(NSNotification*) notification;


@end
