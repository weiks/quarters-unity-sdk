//
//  UniversalDeepLinkDelegate.h
//  UniversalDeepLink
//
//  Created by Ana Correia on 06/04/2018.
//  Copyright © 2018 ImaginationOverflow. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "LinkerManager.h"
#import <CoreSpotlight/CoreSpotlight.h>

@interface UniversalDeepLinkAppDelegate : NSObject


-(BOOL)application:(UIApplication*) application didFinishLaunchingWithOptions:(NSDictionary*) launchOptions;
-(BOOL)application:(UIApplication*) application
           openURL:(NSURL*) url
           options:(NSDictionary<NSString*, id>*) options;
-(BOOL)application:(UIApplication*) application
           openURL:(NSURL*) url
 sourceApplication:(NSString*) sourceApplication
        annotation:(id) annotation;




-(BOOL)application:(UIApplication *)application continueUserActivity:(NSUserActivity *)userActivity restorationHandler:(void(^)(NSArray * __nullable restorableObjects))restorationHandler;

-(BOOL)_Universal_Deep_Link_Plugin_Application:(UIApplication*) application
                 didFinishLaunchingWithOptions:(NSDictionary*) launchOptions;
-(BOOL)_Universal_Deep_Link_Plugin_Application:(UIApplication*) application
                                       openURL:(NSURL*) url
                                       options:(NSDictionary<NSString*, id>*) options;
-(BOOL)_Universal_Deep_Link_Plugin_Application:(UIApplication*) application
                                       openURL:(NSURL*) url
                             sourceApplication:(NSString*) sourceApplication
                                    annotation:(id) annotation;

-(BOOL)_Universal_Deep_Link_Plugin_Application:(UIApplication *)application
                          continueUserActivity:(NSUserActivity *)userActivity

                            restorationHandler:(void(^)(NSArray * restorableObjects))restorationHandler;


@end






