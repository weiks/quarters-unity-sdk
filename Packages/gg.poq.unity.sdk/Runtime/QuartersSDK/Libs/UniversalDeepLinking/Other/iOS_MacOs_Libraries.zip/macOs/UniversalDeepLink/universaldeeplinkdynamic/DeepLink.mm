#import <Foundation/Foundation.h>
#import "LinkerManager.h"

//typedef void (*EventCallback)(const char * link);

extern "C"
{
    
    void DeepLink_RegisterCallback(EventCallback callback)
    {
        NSLog(@"[LinkerManager2 load] %@", [NSThread currentThread]);
        
        SEL registerMethod;

        registerMethod = NSSelectorFromString( @"registerCallback:" );
        
        LinkerManager * instance =[[[NSThread currentThread] threadDictionary] objectForKey:@"_universalDeepLinkMInstance"];
        
        if(instance == nil)
        {
            return;
        }
        
        NSLog(@"[LinkerManager2 load] %@", instance);

        [instance registerCallback:callback];
    }
    
}

